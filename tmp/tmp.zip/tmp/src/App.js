import logo from './logo.svg';
import './App.css';
import Map3D from './MapboxExample';





function App() {
  return (
    <Map3D/>
  );
}

export default App;
